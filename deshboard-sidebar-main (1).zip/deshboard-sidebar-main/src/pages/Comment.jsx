import React from 'react';

const Comment = () => {
    return (
        <div>
            <h1>Comment page</h1>
        </div>
    );
};

export default Comment;