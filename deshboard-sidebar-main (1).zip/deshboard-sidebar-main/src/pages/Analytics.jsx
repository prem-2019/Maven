import React from 'react';

const Analytics = () => {
    return (
        <div>
            <h1>Analytics page</h1>
        </div>
    );
};

export default Analytics;