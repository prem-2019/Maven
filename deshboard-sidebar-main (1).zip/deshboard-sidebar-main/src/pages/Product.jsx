import React from 'react';

const Product = () => {
    return (
        <div>
            <h1>product page</h1>
        </div>
    );
};

export default Product;