package com.example.ProductProducer;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MessageController {
@PostMapping("/send")
	public String sendMessage (@RequestBody String message) {
	
		// TODO Auto-generated method stub
return "Message sent:" + message;
	}

}
