package com.example.producer;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MessageController {
@PostMapping("/send")
	public String sendMessage(@RequestBody String message) {
	//process the received message(e.g,send it to rabbitMQ)
	//for simplicity,just return a confirmation message
	return "Message sent:" + message;
	}

}
